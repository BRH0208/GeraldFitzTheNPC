using Terraria.ModLoader;

namespace Test
{
	public class Test : Mod
	{
	}
}